var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

/* Modernizr 2.0.6 (Custom Build) | MIT & BSD
* Build: http://www.modernizr.com/download/#-csstransforms-csstransforms3d-canvas-audio-video-localstorage-sessionstorage-geolocation-teststyles-testprop-prefixes
*/
; window.Modernizr = function (a, b, c) { function z(a, b) { for (var d in a) if (j[a[d]] !== c) return b == "pfx" ? a[d] : !0; return !1 } function y(a, b) { return !! ~("" + a).indexOf(b) } function x(a, b) { return typeof a === b } function w(a, b) { return v(m.join(a + ";") + (b || "")) } function v(a) { j.cssText = a } var d = "2.0.6", e = {}, f = b.documentElement, g = b.head || b.getElementsByTagName("head")[0], h = "modernizr", i = b.createElement(h), j = i.style, k, l = Object.prototype.toString, m = " -webkit- -moz- -o- -ms- -khtml- ".split(" "), n = {}, o = {}, p = {}, q = [], r = function (a, c, d, e) { var g, i, j, k = b.createElement("div"); if (parseInt(d, 10)) while (d--) j = b.createElement("div"), j.id = e ? e[d] : h + (d + 1), k.appendChild(j); g = ["&shy;", "<style>", a, "</style>"].join(""), k.id = h, k.innerHTML += g, f.appendChild(k), i = c(k, a), k.parentNode.removeChild(k); return !!i }, s, t = {}.hasOwnProperty, u; !x(t, c) && !x(t.call, c) ? u = function (a, b) { return t.call(a, b) } : u = function (a, b) { return b in a && x(a.constructor.prototype[b], c) }; var A = function (a, c) { var d = a.join(""), f = c.length; r(d, function (a, c) { var d = b.styleSheets[b.styleSheets.length - 1], g = d.cssRules && d.cssRules[0] ? d.cssRules[0].cssText : d.cssText || "", h = a.childNodes, i = {}; while (f--) i[h[f].id] = h[f]; e.csstransforms3d = i.csstransforms3d.offsetLeft === 9 }, f, c) } ([, ["@media (", m.join("transform-3d),("), h, ")", "{#csstransforms3d{left:9px;position:absolute}}"].join("")], [, "csstransforms3d"]); n.canvas = function () { var a = b.createElement("canvas"); return !!a.getContext && !!a.getContext("2d") }, n.geolocation = function () { return !!navigator.geolocation }, n.csstransforms = function () { return !!z(["transformProperty", "WebkitTransform", "MozTransform", "OTransform", "msTransform"]) }, n.csstransforms3d = function () { var a = !!z(["perspectiveProperty", "WebkitPerspective", "MozPerspective", "OPerspective", "msPerspective"]); a && "webkitPerspective" in f.style && (a = e.csstransforms3d); return a }, n.video = function () { var a = b.createElement("video"), c = !1; try { if (c = !!a.canPlayType) { c = new Boolean(c), c.ogg = a.canPlayType('video/ogg; codecs="theora"'); var d = 'video/mp4; codecs="avc1.42E01E'; c.h264 = a.canPlayType(d + '"') || a.canPlayType(d + ', mp4a.40.2"'), c.webm = a.canPlayType('video/webm; codecs="vp8, vorbis"') } } catch (e) { } return c }, n.audio = function () { var a = b.createElement("audio"), c = !1; try { if (c = !!a.canPlayType) c = new Boolean(c), c.ogg = a.canPlayType('audio/ogg; codecs="vorbis"'), c.mp3 = a.canPlayType("audio/mpeg;"), c.wav = a.canPlayType('audio/wav; codecs="1"'), c.m4a = a.canPlayType("audio/x-m4a;") || a.canPlayType("audio/aac;") } catch (d) { } return c }, n.localstorage = function () { try { return !!localStorage.getItem } catch (a) { return !1 } }, n.sessionstorage = function () { try { return !!sessionStorage.getItem } catch (a) { return !1 } }; for (var B in n) u(n, B) && (s = B.toLowerCase(), e[s] = n[B](), q.push((e[s] ? "" : "no-") + s)); v(""), i = k = null, e._version = d, e._prefixes = m, e.testProp = function (a) { return z([a]) }, e.testStyles = r; return e } (this, this.document);

}
/*
     FILE ARCHIVED ON 21:45:05 Dec 31, 2013 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 18:30:31 Apr 26, 2025.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 0.58
  exclusion.robots: 0.022
  exclusion.robots.policy: 0.01
  esindex: 0.01
  cdx.remote: 13.271
  LoadShardBlock: 232.994 (6)
  PetaboxLoader3.datanode: 242.113 (8)
  load_resource: 287.015 (2)
  PetaboxLoader3.resolve: 200.299 (2)
*/